"""
Flappy Bird - Python/Pygame
Chạy: python main.py
Cài pygame: pip install pygame
"""

import pygame
import random
import sys

# ── Khởi tạo ──────────────────────────────────────────────────────────────────
pygame.init()

# ── Hằng số ───────────────────────────────────────────────────────────────────
SCREEN_W, SCREEN_H = 400, 600
FPS            = 60
GRAVITY        = 0.45
JUMP_FORCE     = -9
PIPE_SPEED     = 3
PIPE_GAP       = 155       # Khoảng trống giữa 2 ống
PIPE_INTERVAL  = 1600      # Mili-giây giữa các cặp ống mới
GROUND_H       = 80        # Chiều cao phần đất phía dưới

# ── Màu sắc ───────────────────────────────────────────────────────────────────
SKY        = (113, 197, 207)
WHITE      = (255, 255, 255)
BLACK      = (  0,   0,   0)
YELLOW     = (255, 204,   0)
YELLOW_LT  = (255, 230, 120)
ORANGE     = (255, 130,   0)
GREEN      = ( 78, 154,   6)
GREEN_DK   = ( 50, 100,   0)
GROUND_CLR = (222, 184, 135)
DIRT       = (139,  90,  43)
GRASS      = (100, 160,  30)


# ══════════════════════════════════════════════════════════════════════════════
class Bird:
    """
    Nhân vật chim.
    - Áp dụng trọng lực mỗi frame (gravity).
    - Nhấn SPACE → jump() đặt vận tốc âm (bay lên).
    - Có 3 frame animation cánh: lên / giữa / xuống.
    """

    WING_FRAMES = 3          # Số frame cánh
    WING_DELAY  = 100        # ms mỗi frame cánh

    def __init__(self, x: int, y: int):
        self.start_x, self.start_y = x, y
        self.reset()

    # ── Khởi tạo lại ──────────────────────────────────────────────────────────
    def reset(self):
        self.x        = float(self.start_x)
        self.y        = float(self.start_y)
        self.velocity = 0.0
        self.rotation = 0.0       # Độ nghiêng đầu chim
        self.wing_frame = 0
        self.wing_timer = 0

    # ── Logic ─────────────────────────────────────────────────────────────────
    def jump(self):
        """Chim vỗ cánh bay lên."""
        self.velocity  = JUMP_FORCE
        self.wing_frame = 0        # Bắt đầu lại animation

    def update(self, dt: int):
        """Cập nhật vật lý và animation cánh. dt tính bằng ms."""
        # Trọng lực
        self.velocity += GRAVITY
        self.velocity  = min(self.velocity, 14)   # Giới hạn tốc độ rơi
        self.y        += self.velocity

        # Góc nghiêng: hướng lên khi nhảy, chúi xuống khi rơi
        self.rotation = max(-30, min(self.velocity * 4.5, 70))

        # Animation vỗ cánh theo thời gian thực
        self.wing_timer += dt
        if self.wing_timer >= self.WING_DELAY:
            self.wing_timer  = 0
            self.wing_frame  = (self.wing_frame + 1) % self.WING_FRAMES

    # ── Vẽ ───────────────────────────────────────────────────────────────────
    def draw(self, screen: pygame.Surface):
        """Vẽ chim lên màn hình, có xoay theo góc nghiêng."""
        W, H = 44, 32
        surf = pygame.Surface((W + 22, H + 12), pygame.SRCALPHA)

        ox, oy = 10, 5   # Offset vẽ trong surface tạm

        # Thân (vàng)
        pygame.draw.ellipse(surf, YELLOW,    (ox,      oy,      W,    H))
        pygame.draw.ellipse(surf, (200,150,0),(ox,      oy,      W,    H), 2)

        # Bụng (vàng nhạt)
        pygame.draw.ellipse(surf, YELLOW_LT, (ox + 5,  oy + 11, 18,  14))

        # Cánh — 3 trạng thái vỗ: -7 (lên) / 0 (giữa) / +7 (xuống)
        wing_dy = [-7, 0, 7][self.wing_frame]
        pygame.draw.ellipse(surf, ORANGE, (ox + 3,  oy + 10 + wing_dy, 16, 10))

        # Mắt
        pygame.draw.ellipse(surf, WHITE,  (ox + W - 14, oy + 4,  13, 13))
        pygame.draw.ellipse(surf, BLACK,  (ox + W - 10, oy + 7,   7,  7))

        # Mỏ
        bx = ox + W - 2
        by = oy + H // 2
        pygame.draw.polygon(surf, ORANGE, [(bx, by - 7), (bx + 13, by), (bx, by + 7)])

        # Xoay toàn bộ surface
        rotated = pygame.transform.rotate(surf, -self.rotation)
        rect    = rotated.get_rect(center=(int(self.x), int(self.y)))
        screen.blit(rotated, rect)

    # ── Hitbox ────────────────────────────────────────────────────────────────
    def get_rect(self) -> pygame.Rect:
        """Hitbox nhỏ hơn hình vẽ một chút để game fair hơn."""
        return pygame.Rect(int(self.x) - 14, int(self.y) - 11, 28, 22)


# ══════════════════════════════════════════════════════════════════════════════
class Pipe:
    """
    Một cặp ống nước (trên + dưới).
    - Khoảng trống sinh ngẫu nhiên trong vùng an toàn.
    - Di chuyển sang trái với tốc độ PIPE_SPEED.
    """

    WIDTH  = 62
    CAP_H  = 22    # Chiều cao phần "nắp" ống

    def __init__(self, x: int):
        self.x      = float(x)
        self.scored = False        # Đã cộng điểm chưa?

        # Tâm khoảng trống ngẫu nhiên
        gap_cy   = random.randint(200, SCREEN_H - GROUND_H - 200)
        self.top    = gap_cy - PIPE_GAP // 2   # Đáy ống trên
        self.bottom = gap_cy + PIPE_GAP // 2   # Đỉnh ống dưới

    # ── Logic ─────────────────────────────────────────────────────────────────
    def update(self):
        self.x -= PIPE_SPEED

    def is_off_screen(self) -> bool:
        return self.x + self.WIDTH < 0

    def collides(self, bird_rect: pygame.Rect) -> bool:
        """Trả True nếu chim đâm vào ống trên hoặc dưới."""
        top_rect    = pygame.Rect(self.x, 0,          self.WIDTH, self.top)
        bottom_rect = pygame.Rect(self.x, self.bottom, self.WIDTH, SCREEN_H)
        return top_rect.colliderect(bird_rect) or bottom_rect.colliderect(bird_rect)

    # ── Vẽ ───────────────────────────────────────────────────────────────────
    def draw(self, screen: pygame.Surface):
        x = int(self.x)
        W = self.WIDTH
        C = self.CAP_H

        # ── Ống trên ──────────────────────────────────────────────────────────
        # Thân
        pygame.draw.rect(screen, GREEN,    (x + 6, 0,             W - 12, self.top - C))
        pygame.draw.rect(screen, GREEN_DK, (x + 6, 0,             W - 12, self.top - C), 2)
        # Nắp
        pygame.draw.rect(screen, GREEN,    (x,     self.top - C,  W,      C))
        pygame.draw.rect(screen, GREEN_DK, (x,     self.top - C,  W,      C), 2)

        # ── Ống dưới ──────────────────────────────────────────────────────────
        # Nắp
        pygame.draw.rect(screen, GREEN,    (x,     self.bottom,       W,      C))
        pygame.draw.rect(screen, GREEN_DK, (x,     self.bottom,       W,      C), 2)
        # Thân
        bot_body_y = self.bottom + C
        pygame.draw.rect(screen, GREEN,    (x + 6, bot_body_y,        W - 12, SCREEN_H))
        pygame.draw.rect(screen, GREEN_DK, (x + 6, bot_body_y,        W - 12, SCREEN_H), 2)


# ══════════════════════════════════════════════════════════════════════════════
class Game:
    """
    Quản lý toàn bộ game.
    Các trạng thái: 'waiting' → 'playing' → 'gameover' → reset về 'waiting'.
    """

    def __init__(self):
        self.screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
        pygame.display.set_caption("Flappy Bird")
        self.clock      = pygame.time.Clock()

        # Font chữ
        self.font_big   = pygame.font.SysFont("Arial", 52, bold=True)
        self.font_mid   = pygame.font.SysFont("Arial", 30, bold=True)
        self.font_small = pygame.font.SysFont("Arial", 20)

        # Đám mây (vị trí cố định, đủ dùng)
        self.clouds = [(55, 75), (195, 48), (325, 108), (140, 165), (290, 55)]

        self.bird = Bird(100, SCREEN_H // 2)
        self.reset()

    # ── Reset về trạng thái ban đầu ───────────────────────────────────────────
    def reset(self):
        self.bird.reset()
        self.pipes      = []
        self.score      = 0
        self.state      = "waiting"   # waiting | playing | gameover
        self.pipe_timer = 0

    # ── Sinh ống mới ──────────────────────────────────────────────────────────
    def _spawn_pipe(self):
        self.pipes.append(Pipe(SCREEN_W + 10))

    # ── Xử lý sự kiện ────────────────────────────────────────────────────────
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                if self.state == "waiting":
                    self.state = "playing"
                    self.bird.jump()
                elif self.state == "playing":
                    self.bird.jump()
                elif self.state == "gameover":
                    self.reset()

    # ── Cập nhật logic game ───────────────────────────────────────────────────
    def update(self, dt: int):
        if self.state != "playing":
            return

        self.bird.update(dt)

        # Sinh ống theo định kỳ
        self.pipe_timer += dt
        if self.pipe_timer >= PIPE_INTERVAL:
            self.pipe_timer = 0
            self._spawn_pipe()

        # Cập nhật và tính điểm
        for pipe in self.pipes:
            pipe.update()
            if not pipe.scored and pipe.x + pipe.WIDTH < self.bird.x:
                pipe.scored = True
                self.score += 1

        # Xóa ống ra khỏi màn hình
        self.pipes = [p for p in self.pipes if not p.is_off_screen()]

        # Va chạm với đất / trần
        ground_y = SCREEN_H - GROUND_H
        if self.bird.y + 15 >= ground_y or self.bird.y - 15 <= 0:
            self.state = "gameover"
            return

        # Va chạm với ống
        bird_rect = self.bird.get_rect()
        for pipe in self.pipes:
            if pipe.collides(bird_rect):
                self.state = "gameover"
                return

    # ── Vẽ nền (bầu trời + mây) ──────────────────────────────────────────────
    def _draw_background(self):
        self.screen.fill(SKY)
        for cx, cy in self.clouds:
            pygame.draw.ellipse(self.screen, WHITE, (cx - 32, cy,      64, 26))
            pygame.draw.ellipse(self.screen, WHITE, (cx - 18, cy - 16, 42, 28))
            pygame.draw.ellipse(self.screen, WHITE, (cx + 4,  cy -  2, 38, 22))

    # ── Vẽ mặt đất ────────────────────────────────────────────────────────────
    def _draw_ground(self):
        gy = SCREEN_H - GROUND_H
        pygame.draw.rect(self.screen, GROUND_CLR, (0, gy, SCREEN_W, GROUND_H))
        pygame.draw.rect(self.screen, DIRT,        (0, gy, SCREEN_W, 8))
        for gx in range(0, SCREEN_W, 22):
            pygame.draw.line(self.screen, GRASS, (gx, gy), (gx + 9, gy - 9), 2)

    # ── Vẽ điểm số ────────────────────────────────────────────────────────────
    def _draw_score(self):
        text  = str(self.score)
        shadow = self.font_big.render(text, True, BLACK)
        score  = self.font_big.render(text, True, WHITE)
        cx = SCREEN_W // 2
        self.screen.blit(shadow, shadow.get_rect(centerx=cx + 2, top=22))
        self.screen.blit(score,  score.get_rect(centerx=cx,      top=20))

    # ── Màn hình chờ ─────────────────────────────────────────────────────────
    def _draw_waiting(self):
        title = self.font_mid.render("Flappy Bird", True, WHITE)
        hint  = self.font_small.render("Nhấn SPACE để bắt đầu", True, (220, 220, 220))
        self.screen.blit(title, title.get_rect(centerx=SCREEN_W // 2, centery=SCREEN_H // 2 + 50))
        self.screen.blit(hint,  hint.get_rect( centerx=SCREEN_W // 2, centery=SCREEN_H // 2 + 95))

    # ── Màn hình Game Over ────────────────────────────────────────────────────
    def _draw_gameover(self):
        # Lớp phủ tối mờ
        overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.screen.blit(overlay, (0, 0))

        go  = self.font_big.render("Game Over",              True, (255, 80,  80))
        sc  = self.font_mid.render(f"Điểm: {self.score}",   True, WHITE)
        rst = self.font_small.render("Nhấn SPACE để chơi lại", True, (200, 200, 200))

        cx = SCREEN_W // 2
        self.screen.blit(go,  go.get_rect( centerx=cx, centery=230))
        self.screen.blit(sc,  sc.get_rect( centerx=cx, centery=295))
        self.screen.blit(rst, rst.get_rect(centerx=cx, centery=345))

    # ── Vòng lặp chính ────────────────────────────────────────────────────────
    def run(self):
        while True:
            dt = self.clock.tick(FPS)    # Thời gian (ms) kể từ frame trước

            self.handle_events()
            self.update(dt)

            # Vẽ theo thứ tự từ dưới lên
            self._draw_background()
            for pipe in self.pipes:
                pipe.draw(self.screen)
            self._draw_ground()
            self.bird.draw(self.screen)
            self._draw_score()

            if self.state == "waiting":
                self._draw_waiting()
            elif self.state == "gameover":
                self._draw_gameover()

            pygame.display.flip()


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    Game().run()
